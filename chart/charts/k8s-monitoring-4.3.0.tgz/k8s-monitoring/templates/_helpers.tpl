{{- define "helper.chart" }}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{ define "helper.k8s_name" }}
{{- . | lower | replace " " "-" -}}
{{ end }}

{{ define "helper.alloy_name" }}
{{- . | lower | replace " " "_" | replace "-" "_" -}}
{{ end }}

{{- define "helper.namespace" -}}
{{- .Values.global.namespaceOverride | default .Release.Namespace -}}
{{- end -}}

{{- define "helper.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" | lower }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride | lower }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" | lower }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" | lower }}
{{- end }}
{{- end }}
{{- end }}

{{- define "english_list" }}
{{- if eq (len .) 0 }}
{{- else if eq (len .) 1 }}
{{- index . 0 }}
{{- else if eq (len .) 2 }}
{{- index . 0 }} and {{ index . 1 }}
{{- else }}
{{- $last := index . (sub (len .) 1) }}
{{- $rest := slice . 0 (sub (len .) 1) }}
{{- join ", " $rest }}, and {{ $last }}
{{- end }}
{{- end }}

{{- define "english_list_or" }}
{{- if eq (len .) 0 }}
{{- else if eq (len .) 1 }}
{{- index . 0 }}
{{- else if eq (len .) 2 }}
{{- index . 0 }} or {{ index . 1 }}
{{- else }}
{{- $last := index . (sub (len .) 1) }}
{{- $rest := slice . 0 (sub (len .) 1) }}
{{- join ", " $rest }}, or {{ $last }}
{{- end }}
{{- end }}

{{- define "label_list" }}
{{- $labels := list }}
{{- range $key, $value := . }}
  {{- $labels = append $labels (printf "%s=\"%s\"" $key $value) }}
{{- end }}
{{- printf "{%s}" ($labels | join ", ") }}
{{- end }}

{{- define "escape_label" -}}
{{ . | replace "-" "_" | replace "." "_" | replace "/" "_" }}
{{- end }}

{{- define "pod_label" -}}
{{ printf "__meta_kubernetes_pod_label_%s" (include "escape_label" .) }}
{{- end }}

{{- define "namespace_label" -}}
{{ printf "__meta_kubernetes_namespace_label_%s" (include "escape_label" .) }}
{{- end }}

{{- define "pod_annotation" -}}
{{ printf "__meta_kubernetes_pod_annotation_%s" (include "escape_label" .) }}
{{- end }}

{{- define "namespace_annotation" -}}
{{ printf "__meta_kubernetes_namespace_annotation_%s" (include "escape_label" .) }}
{{- end }}

{{- define "ec2_tag" -}}
{{ printf "__meta_ec2_tag_%s" (regexReplaceAll "[^0-9A-Za-z_]" . "_") }}
{{- end }}
