{{/*
Expand the name of the chart.
*/}}
{{- define "metrics-server.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "metrics-server.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "metrics-server.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "metrics-server.labels" -}}
helm.sh/chart: {{ include "metrics-server.chart" . }}
{{ include "metrics-server.selectorLabels" . }}
{{ include "metrics-server.xenon.serviceTreeLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- if .Values.commonLabels }}
{{ toYaml .Values.commonLabels }}
{{- end }}
{{- end }}

{{/*
Render the wrapper-owned service-tree identity in the dependency context. Global
values are Helm's supported parent-to-subchart contract; platform is always the
release namespace and can never be supplied independently.
*/}}
{{- define "metrics-server.xenon.serviceTreeLabels" -}}
{{- $prefix := required "global.labelPrefix is required" .Values.global.labelPrefix | trimSuffix "/" -}}
{{- $serviceTree := required "global.serviceTree is required" .Values.global.serviceTree -}}
{{- $service := required "global.serviceTree.service is required" $serviceTree.service -}}
{{- $module := required "global.serviceTree.module is required" $serviceTree.module -}}
{{- $layer := required "global.serviceTree.layer is required" $serviceTree.layer -}}
{{ printf "%s/platform" $prefix }}: {{ .Release.Namespace | quote }}
{{ printf "%s/service" $prefix }}: {{ $service | quote }}
{{ printf "%s/module" $prefix }}: {{ $module | quote }}
{{ printf "%s/layer" $prefix }}: {{ $layer | quote }}
{{- with $serviceTree.landscape }}
{{ printf "%s/landscape" $prefix }}: {{ . | quote }}
{{- end }}
{{- with $serviceTree.cluster }}
{{ printf "%s/cluster" $prefix }}: {{ . | quote }}
{{- end }}
{{- end }}

{{/* Service-tree annotations use the same single prefix and namespace identity. */}}
{{- define "metrics-server.xenon.serviceTreeAnnotations" -}}
{{- include "metrics-server.xenon.serviceTreeLabels" . -}}
{{- end }}

{{/* Build an exactly-one-dash resource name from the wrapper service + token. */}}
{{- define "metrics-server.xenon.resourceName" -}}
{{- $serviceTree := required "global.serviceTree is required" .root.Values.global.serviceTree -}}
{{- $service := required "global.serviceTree.service is required" $serviceTree.service | lower -}}
{{- $token := required "resource token is required" .token | lower -}}
{{- $token = regexReplaceAll "[^a-z0-9]+" $token "" -}}
{{- if not (regexMatch "^[a-z0-9]+$" $service) -}}
{{- fail (printf "service %q must be dash-less lowercase alphanumeric" $service) -}}
{{- end -}}
{{- if not (regexMatch "^[a-z0-9]+$" $token) -}}
{{- fail (printf "token %q must normalize to a dash-less lowercase token" .token) -}}
{{- end -}}
{{- printf "%s-%s" $service $token -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "metrics-server.selectorLabels" -}}
app.kubernetes.io/name: {{ include "metrics-server.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "metrics-server.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "metrics-server.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
The image to use
*/}}
{{- define "metrics-server.image" -}}
{{- printf "%s:%s" .Values.image.repository (default (printf "v%s" .Chart.AppVersion) .Values.image.tag) }}
{{- end }}

{{/*
The image to use for the addon resizer
*/}}
{{- define "metrics-server.addonResizer.image" -}}
{{- printf "%s:%s" .Values.addonResizer.image.repository .Values.addonResizer.image.tag }}
{{- end }}

{{/*
ConfigMap name of addon resizer
*/}}
{{- define "metrics-server.addonResizer.configMap" -}}
{{- include "metrics-server.xenon.resourceName" (dict "root" . "token" "nannyconfig") }}
{{- end }}

{{/*
Role name of addon resizer
*/}}
{{- define "metrics-server.addonResizer.role" -}}
{{- include "metrics-server.xenon.resourceName" (dict "root" . "token" "nannyrole") }}
{{- end }}

{{/* Get PodDisruptionBudget API Version */}}
{{- define "metrics-server.pdb.apiVersion" -}}
  {{- if and (.Capabilities.APIVersions.Has "policy/v1") (semverCompare ">= 1.21-0" .Capabilities.KubeVersion.Version) -}}
      {{- print "policy/v1" -}}
  {{- else -}}
    {{- print "policy/v1beta1" -}}
  {{- end -}}
{{- end -}}
